# Prince Phiri Music — Website
Static, responsive site ready for hosting on Netlify, GitHub Pages, or any web host.

## Quick Start
1. Edit links for Spotify/Apple/YouTube on `index.html` and `music.html`.
2. Replace placeholder images in `assets/img/`.
3. Update `data/shows.json` with your real dates.
4. Connect the contact forms to Formspree (replace `your-id`).

## Deploy
- **Netlify:** drag-and-drop this folder.
- **GitHub Pages:** push and enable Pages.
- **cPanel/FTP:** upload the folder to `public_html`.

© 2025 Prince Phiri Music

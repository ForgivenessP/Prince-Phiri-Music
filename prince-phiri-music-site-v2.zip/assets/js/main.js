
document.addEventListener('DOMContentLoaded', async () => {
  // Populate shows from JSON
  const tableBody = document.querySelector('#shows-table tbody');
  if (tableBody) {
    try {
      const res = await fetch('data/shows.json');
      const shows = await res.json();
      shows.sort((a,b)=> new Date(a.date) - new Date(b.date));
      for (const s of shows) {
        const tr = document.createElement('tr');
        const date = new Date(s.date).toLocaleDateString(undefined, {year:'numeric', month:'short', day:'numeric'});
        tr.innerHTML = `<td>${date}</td><td>${s.city}</td><td>${s.venue}</td><td>${s.status}</td>
                        <td>${s.status==='On Sale' ? '<a class="btn" href="#">Tickets</a>' : '-'}</td>`;
        tableBody.appendChild(tr);
      }
    } catch(e){ console.warn('Shows JSON missing', e); }
  }
});
